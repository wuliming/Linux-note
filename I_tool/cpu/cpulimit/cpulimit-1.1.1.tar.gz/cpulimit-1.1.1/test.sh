sleep 10 &
wait
echo hi
